export const SETTINGS_SCHEMAS = []
